package Principal;

import Gui.MiFrame;

/**
 *
 * Creado el 24 de Febrero, 2022, 22:00 horas
 *
 * @description Ingreso de datos por medio de GUI
 * @author Kevin Andres Condo Chaguay
 *
 * @version POO - 2022
 *
 */
public class principal {

    public static void main(String[] args) {
        MiFrame frame = new MiFrame();

        //estable como visible la pantalla
        frame.setVisible(true);
    }
}
